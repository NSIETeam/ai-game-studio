# Agent Legion Skill Pack

## 简介
这是一个多 Agent AI 游戏工作室的 Skill 包，包含六个专业 Agent 的完整实现：

1. **Planner Agent**：游戏策划师
2. **Level Designer Agent**：关卡设计师
3. **Coder Agent**：游戏工程师
4. **Artist Agent**：美术师
5. **Tester Agent**：测试师
6. **Director Agent**：总监 Agent

## 安装说明
1. 解压此 zip 文件
2. 将 skills 目录复制到你的 EasyClaw skills 目录
3. 重启 EasyClaw
4. 在会话中使用 /invoke 调用相应 Agent

## 使用示例
```
/invoke planner "设计一个 Krigger 风格的 3D 空战游戏"
/invoke level-designer "创建 5 个关卡，难度递增"
/invoke coder "使用 Three.js 实现零式战斗机模型"
/invoke artist "生成过程着色风格的材质"
/invoke tester "测试游戏的可玩性和 bug"
/invoke director "整合所有 Agent 的输出"
```

## 版本
v1.0.0

## 作者
NSIETeam