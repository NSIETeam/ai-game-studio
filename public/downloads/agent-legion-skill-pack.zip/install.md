# 安装说明

## 步骤

1. **解压 zip 文件**
   ```bash
   unzip agent-legion-skill-pack.zip
   ```

2. **复制到 EasyClaw skills 目录**
   ```bash
   cp -r agent-legion-skill-pack/skills ~/.easyclaw/skills/
   ```

3. **重启 EasyClaw**
   ```bash
   easyclaw gateway restart
   ```

4. **测试安装**
   ```bash
   easyclaw invoke planner "测试安装"
   ```

## 要求
- EasyClaw v1.0.0 或更高版本
- 支持 subagent 功能
- 至少 1GB 内存

## 常见问题

### Q: 安装后看不到 Skill
A: 检查是否复制到正确目录，重启 EasyClaw

### Q: Agent 无法调用
A: 检查网络连接，确认 API 配置正确

### Q: 输出不符合预期
A: 尝试更详细的提示词，调整 Agent 参数