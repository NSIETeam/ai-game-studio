import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  base: '/ai-game-studio/',
  build: {
    outDir: 'docs', // GitHub Pages uses docs/ or root
  },
})
